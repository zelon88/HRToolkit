<?php

 echo nl2br('It is currently '.$date.". \r");  
 echo nl2br("--------------------------------\r");