<?php

$WRDHRAI = 'HRAI';
$greeting = 1;
$statement = 0;
$question = 0;
$attitude = 0;
$mood = 0;
$noun = 1;
$self = 1;
$verb = 0;
$adj = 0;
$synonyms = array('machine','Machine','AI','ai');
$antonyms = 0;