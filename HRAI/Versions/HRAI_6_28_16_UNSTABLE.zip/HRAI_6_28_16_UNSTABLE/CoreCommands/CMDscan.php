
<?php
echo nl2br('Yes, sir! '."\r");
echo nl2br('Establishing connection to HRCloud servers.'."\r");
?>
<script type="text/javascript">
document.getElementById("HRScan_Iframe").submit();
</script></div>
<iframe id="HRScan_Iframe" src="http://localhost/HRProprietary/scanner/uploadbuttonhtmlNOGUI.php" name="HRScan" width="275" scrolling="yes" margin-top:-4px; margin-left:-4px; border:double;></iframe>
</form>
</div>


<?php
echo nl2br("--------------------------------\r");