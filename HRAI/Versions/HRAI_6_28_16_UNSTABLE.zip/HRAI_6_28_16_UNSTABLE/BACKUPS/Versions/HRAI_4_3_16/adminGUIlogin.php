<form action="/HRProprietary/HRAI/adminGUI.php" method="post">
	<p>Username: <input type="text" name="adunm" value=""></p>
	<p>Password: <input type="password" name="adpwd" value=""></p>
	<p><input type="submit" value="Start Core!"></p>

</form>