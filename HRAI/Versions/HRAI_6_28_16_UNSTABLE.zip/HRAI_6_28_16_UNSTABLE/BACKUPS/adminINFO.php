<?php

// SECRET: Set the default admin username, password and name here. HRAI requires these to be 
// SECRET: completely separate and independant from any other framework (like WordPress).

// /----------------------------------------------------------------------------------------
// SECRET: Admin Username ...
  $adunm1 = 'salad';
// SECRET: Admin Password ...
  $adpwd1 = 'tosser32';
// SECRET: Admin Display Name ...
  $display_name = 'Justin';
// /----------------------------------------------------------------------------------------
