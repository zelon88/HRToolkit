<?php

$WRDhey = "hey";
$greeting = 1;
$statement = 0;
$question = 0;
$noun = 0;
$verb = 0;
$adj = 0;
$attitude = 1;
$mood = 0;
$synonyms = array('Hey');
