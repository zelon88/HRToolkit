<?php

$WRDhello = "hello";
$greeting = 1;
$statement = 0;
$question = 0;
$attitude = 0;
$mood = 0;
$noun = 0;
$verb = 0;
$adj = 0;
$synonyms = array('Hello','Hi');
$antonyms = array('Googbye','goodbye','Bye','bye');