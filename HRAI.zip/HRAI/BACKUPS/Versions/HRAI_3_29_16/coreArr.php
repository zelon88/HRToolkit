<?php

$firstwordTypeBasic = array('how', 'why', 'can', 'cant', 'when', 'why', 'are', 'will', 'is', 'if', 'could', 'would', 'should', );