
<?php
echo nl2br('Yes, sir! '."\r");
echo nl2br('Establishing connection to HRCloud servers.'."\r");
?>
<script type="text/javascript">
document.getElementById("HRConvert_Iframe").submit();
</script></div>
<iframe id="HRConvert_Iframe" src="http://localhost/HRProprietary/converter/uploadbuttonhtmlNOGUI.php" name="HRConvert" width="275" scrolling="yes" margin-top:-4px; margin-left:-4px; border:double;></iframe>
</form>
</div>


<?php
echo nl2br("--------------------------------\r");