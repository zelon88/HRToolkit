 
<html>

 <head>
  <title>HRCloud Convert File Uploader</title>
 </head>

 <body>
 <div align="center">
  <h3>File Upload</h3>
  Select a file:
  <br>
  <form action="/HRProprietary/scanner/uploaderNOGUI.php" method="post" enctype="multipart/form-data">
  <input type="file" name="file" size="45">
  <br>
  <input type="submit" name="submitNew" value="Upload">
  </form>
</div>
 </body>

</html>