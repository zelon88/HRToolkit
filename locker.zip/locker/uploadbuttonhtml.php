 
<html>

 <head>
  <title>HRLocker File Uploader</title>
 </head>

 <body>
 	<div align="center">
 	<a href="http://cloud.honestrepair.net">
<img src="http://cloud.honestrepair.net/HRProprietary/converter/HRBanner.png" alt="HonestRepair"> </a></div>
<br>
 <div align="center">
 	HRLocker uses the power of the HonestRepair Cloud Platform to encrypt or decrypt almost anything. To begin, select a file to
 	upload to our servers for processing.
 	<br>
  <h3>File Upload</h3>
  Select a file to upload:
  <br>
  <form action="/HRProprietary/locker/uploader.php" method="post" enctype="multipart/form-data">
  <input type="file" name="file" size="45">
  <br>
  <input type="submit" name="submitNew" value="Upload">
  </form>
</div>
 </body>

</html>