 
<html>

 <head>
  <title>HRCloud Convert File Uploader</title>
 </head>

 <body>
 	<div align="center">
 	<a href="http://localhost">
<img src="http://localhost/HRProprietary/converter/HRBanner.png" alt="HonestRepair"> </a></div>
<br>
 <div align="center">
 	HRCloud Convert uses the power of the HonestRepair Cloud Platform to convert almost anything into almost anything else. To begin, select a file to
 	upload to our servers for processing.
 	<br>
  <h3>File Upload</h3>
  Select a file to upload:
  <br>
  <form action="/HRProprietary/converter/uploader.php" method="post" enctype="multipart/form-data">
  <input type="file" name="file" size="45">
  <br>
  <input type="submit" name="submitNew" value="Upload">
  </form>
</div>
 </body>

</html>