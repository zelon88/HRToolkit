<!DOCTYPE html>
<html>
<head>
<title>DocumentControl | Logs Summary Window </title>
<link rel="stylesheet" type="text/css" href="DocConCSS.css">
</head>

<body>
	<div align='center'><h3>Logs</h3></div>
	<hr />
	<div align='left'>
<?php echo nl2br ("\n".'DocumentControl keeps permanent logs of all Operational Activity. '."\n\n"); ?>
<hr />
</div>
</body>
</html>