<?php

require_once ("config.php");

$Files = scandir($InputLoc);

foreach ($Files as $File) {
$PathInfo = pathinfo("$File");
$FileName = $PathInfo['filename'];
$FileType = $PathInfo['filetype'];
$Matches = preg_grep ($FileName, $PrefixArr);
  if (in_array('SO',$PrefixArr) { 
    $FileName1 = preg_replace('so', '', $FileName);
    $SONum = substr($FileName1,0,$SOC1);
    $SO = 'SO'.$SONum;
    $SORestRaw = preg_replace($SONum, '', $FileName1);
    $SORestRaw = preg_replace($SOSuf, '', $SORestRaw);
    if (preg_match($INSepChar, $SORestRaw) { 
      $SOLineNum = preg_replace($INSepChar, '', $SORestRaw); }
    elseif (!preg_match($INSepChar, $SORestRaw)) {
    	if ($SORestRaw !== '') {
    	  $SOLineNum = $SORestRaw; }
    	if ($SORestRaw == '') {
    	  $SOLineNum = 1; } }
if ($ENABLE_MYSQL == '1') {
// / STILL UNDER DEVELOPMENT !!!
  // / We use the infornation we have to gather more information from MySQL. 
$OPEN_SQL = mysqli_connect("$DBAdr", "DBUser", "DBPass", "DBName");
  if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit(); } 
$SODataRaw = $OPEN_SQL->query("SELECT $SO FROM SO"));
$CLOSE_SQL->close(); }
/// / ------------------------------
if ($SOSuf == '') {
  $CleanSuf = ''; }
elseif ($SOSuf !== '') { 
  $CleanSuf = $OUTSepChar.$SOSuf; }
  $NEWFileName = ('SO'.$SONum.$OUTSepChar.$SOLineNum.'.'.$CleanSuf.$FileType);
  $NEWPathName = $OuputLoc.'/'.$NEWFileName;
  $COPY_IT = rename($PathName, $NEWPathName); }  
}