
<html>

 <head>
  <title>DocumentControl | File Uploader</title>
 </head>
 <body>

<div >

<div align="center" style="max-width:400px"><h3>Submit a new document...</h3></div> 

<hr />
<div align="left">
<form method="post" action="Uploader2.php" enctype="multipart/form-data">
<input name="filesToUpload[]" id="filesToUpload" type="file" multiple="" />
<input type="submit" value="Submit Document" id="filesToUpload" name="submit"></form>

<hr />
</div>

</div>
</body>

</html>


