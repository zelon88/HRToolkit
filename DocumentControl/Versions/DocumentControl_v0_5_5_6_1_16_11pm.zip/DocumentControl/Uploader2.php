<html>
 <head>
  <title>DocumentControl | File Uploader</title>
 </head>
 <body>
<html>
 <head>
  <title>DocumentControl | File Uploader</title>
 </head>
 <body>

<?php
require_once("config.php"); 
if (!isset($_FILES)) { ?>
<div >
<div align="center" style="max-width:400px"><h3>Submit a new document...</h3></div> 
<hr />
<div align="left">
<form method="post" action="Uploader2.php" enctype="multipart/form-data">
<input name="filesToUpload[]" id="filesToUpload" type="file" multiple="" />
<input type="submit" value="Submit Document" id="filesToUpload" name="submit"></form>
<hr />
</div>
</div>
<?php } ?>
<?php
$fc = 0;
if (!isset($_FILES)) { 

  foreach ($_FILES['filesToUpload']['name'] as $file) {
    $fc++;
$allowed =  array('txt', 'doc', 'docx', 'rtf' ,'xls', 'xlsx', 'ods', 'odf', 'odt', 'pdf', 'abw', 'zip', '7z', 'rar', 'tar', 'tar.gz', 'tar.bz2');
$docarray =  array('dat', 'pages', 'cfg', 'txt', 'doc', 'docx', 'rtf', 'odf', 'odt', 'abw');
$spreadarray = array ('xls', 'xlsx', 'ods');
$pdfarray = array('pdf');
$abwarray = array('abw');
$archarray = array('zip', '7z', 'rar', 'tar', 'tar.gz', 'tar.bz2', 'iso', 'vhd');
$filename = str_replace(" ", "_", $file);
$filename1 = pathinfo($filename, PATHINFO_FILENAME);
$ext = pathinfo($filename, PATHINFO_EXTENSION);
if(!in_array($ext,$allowed) ) {
  die('Unsupported file format. Please upload documents only!'); }
if($filename == "") {
die("No file specified"); } }

  if ($fc > 1) { ?> <div align="left"><ul>
   <li>Sent: <?php echo $fc; ?> files.</li>
  </div> <?php } ?>
<?php if ($fc<=1) { ?> <div align="left"><ul>
   <li>Sent: <?php echo $file['file']['name']; ?></li>
   <li>Size: <?php echo $file['file']['size']; ?> bytes</li>
   <li>Type: <?php echo $file['file']['type']; ?></li>
  </div> <?php } } ?>

<?php if (isset($_FILES)) { ?>
<div align="center"><img src="document.png" alt="Your Document"> </a></div>
<?php } ?>

<br><hr>
<?php if ($fc > 1) { ?>
<div align="center"><h3>Control these files...</h3></div>
<?php }
if ($fc <= 1) { ?>
<div align="center"><h3>Control this file...</h3></div>
<?php } ?>
<div align="center">
<?php if (isset($_FILES['filesToUpload']['name'])) { ?>
<div style="max-width:400px">
<div align="center">
<form action="" method="post" enctype="multipart/form-data">
 <select name="selected">
  <option value="pn">Process Now...</option>
  <option value="aai">Add to Action Items...</option>
  <option value="apd">Add to Pending Documents...</option>
 </select>
  <input type="hidden" name="hiddenFile" value="test" />
  <div id="loading" style="display:none;"><img 
    src="/HRProprietary/converter/pacman.gif" /> • • • • •</div>
  <p><input type="submit" name="add" value="Add Document..." onclick="$('#loading').show();"/></p>

 </form>
</div>
<?php }  ?>

</body>

</html>
