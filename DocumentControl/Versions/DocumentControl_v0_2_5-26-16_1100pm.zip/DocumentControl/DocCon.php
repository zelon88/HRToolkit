<?php
require ("config.php");
$PrefixArr = array($SOPre, $WOPre, $POPre, $CERTPre, $InspPre, $PrintPre);
$SuffixArr = array($SOSuf, $WOSuf, $POSuf, $CERTSuf, $InspSuf, $PrintSuf);
$FirstCCArr = array($SOC1, $WOC1, $POC1, $PrC1);
$SecondCCArr = array($SOC2, $WOC2, $POC2, $PrC2);
$Date = date("m_d_y");
$Time = date("F j, Y, g:i a"); 

function EnableClamAV() {
  if ($VirusScan == '1') {
    shell_exec(freshclam); } 
    return '1'; }

  if ($Online == '') {
    die (' ERROR DC16, '.$Time.', You have not yet setup the DocumentControl configuration file! Please 
      view and completely fill-out the settings or config.php file in your root DocumentControl
      directory. '); }
  if ($Online == '0') { 
    $CleanConfig = '1';
    $INTIP = 'localhost';
    $EXTIP = 'localhost'; }
  elseif ($Online !== '0') {
    $CleanConfig = '1';
    $INTIP = $InternalIP; 
    $EXTIP = $ExternalIP; }
  if (isset ($InternalIP)) { 
    unset ($InternalIP); }
  if (isset ($ExternalIP)) { 
    unset ($ExternalIP); }  
  
if ($CleanConfig !== '1') {
  die (' ERROR DC33, '.$Time.', DocumentControl could not validate the configuration file! 
    Please verify the application settings and try again. The application has been halted. '); }

$Files = scandir($InputLoc);
$ClamLog = ($InstLoc.'/'.'VirusLogs'.'/'.$Date.'.txt');
if ($VirusScan == '1') {
  if (file_exists($InputLoc)) {
  shell_exec("sudo clamscan -r $InputLoc | grep FOUND >> $ClamLog"); }
  if (!file_exists($InputLoc)) {  
  die(' ERROR DC42, '.$Time.', There was an error during a routine scan. Please check the Input Location setting and try again. The operation has been haulted. ');
 if( strpos(file_get_contents("$ClamLog"),'FOUND') !== false) {
        die(' !!! WARNING !!! DC44, '.$Time.',DocumentControl detected potentially infected files during a routine scan. 
          Please check the VirusLogs and remove or clean the infected file before running the application again. '); } } }

$FileCount = 0;
if (count(glob("path/*")) === 0 ) {
  die(' Operation Complete! Processed '.$FileCount.' files on '.$Time.'. DC49. '); }

foreach ($Files as $File) {
$PathInfo = pathinfo("$File");
$FileName = $PathInfo['filename'];
$FileType = $PathInfo['filetype'];
$FileCount++;
$Matches = preg_grep ($FileName, $PrefixArr);
  if (in_array('SO',$PrefixArr)) { 
    $FileName1 = preg_replace('so', '', $FileName);
    $SONum = substr($FileName1,0,$SOC1);
    $SO = 'SO'.$SONum;
    $SORestRaw = preg_replace($SONum, '', $FileName1);
    $SORestRaw = preg_replace($SOSuf, '', $SORestRaw);
    if (preg_match($INSepChar, $SORestRaw)) { 
      $SOLineNum = preg_replace($INSepChar, '', $SORestRaw); }
    elseif (!preg_match($INSepChar, $SORestRaw)) {
    	if ($SORestRaw !== '') {
    	  $SOLineNum = $SORestRaw; }
    	if ($SORestRaw == '') {
    	  $SOLineNum = '1'; } }
//if ($ENABLE_MYSQL == '1') {
// / STILL UNDER DEVELOPMENT !!!
  // / We use the infornation we have to gather more information from MySQL. 
//$OPEN_SQL = mysqli_connect("$DBAdr", "DBUser", "DBPass", "DBName");
  //if (mysqli_connect_errno()) {
   // printf("Connect failed: %s\n", mysqli_connect_error());
   // exit(); } 
//$SODataRaw = (($OPEN_SQL->query("SELECT $SO FROM SO"));
//$CLOSE_SQL->close(); }
/// / ------------------------------
if ($SOSuf == '') {
  $CleanSuf = ''; }
elseif ($SOSuf !== '') { 
  $CleanSuf = $OUTSepChar.$SOSuf; }
  $NEWFileName = ('SO'.$SONum.$OUTSepChar.$SOLineNum.'.'.$CleanSuf.$FileType);
  $NEWPathName = $OuputLoc.'/'.$NEWFileName;
  $COPY_IT = rename($PathName, $NEWPathName); 
  echo nl2br("/nCopied $FileName to $NEWPathName on $Time".'.'."/n"); }  } 

if (count(glob("path/*")) === 0 ) {
  die(' Operation Complete! Processed '.$FileCount.' files on '.$Time.'. DC90. '); }
